# Chapter 1 — Why AI Engineering Is Different

## Introduction: A New Kind of Software Component

Engineers already know how to work with components whose behavior is complex. Databases choose query plans. Compilers optimize code. Distributed systems reorder events. Search engines rank documents rather than returning a single logically necessary result. Machine-learning classifiers have always introduced uncertainty.

Large language models are therefore not the first probabilistic systems in software engineering.

They are different for another reason: they combine probabilistic behavior with a remarkably general natural-language interface. The same component can summarize a design, propose code, call a tool, classify an incident, critique an argument, draft a test plan, and explain its own output. Because the interface resembles human communication, users easily attribute more stable understanding, memory, intention, and authority to the system than the implementation warrants.

This mismatch produces the familiar experience in which AI feels extraordinary one moment and strangely incompetent the next. The model may explain a subtle architectural tradeoff and then invent an API that does not exist. It may follow a complex instruction and later overlook a constraint included in the same conversation. It may generate a correct implementation faster than an engineer could type it, yet require more time to verify than writing the code directly.

The problem is not adequately explained by saying that users need “better prompts.” Prompt construction matters, but it is only one layer. The deeper problem is that engineers need a correct model of the component they are controlling.

This chapter develops that model.

---

## 1. Traditional Programs and Generative Models Solve Different Problems

A conventional program maps explicitly represented input to behavior specified by code. Even when the system is concurrent, distributed, or nondeterministic, engineers normally define the permitted state transitions and invariants.

A language model is trained differently. At a simplified level, an autoregressive language model estimates the probability of the next token given preceding tokens. During use, it repeatedly selects tokens to construct a continuation. Modern systems add instruction tuning, preference optimization, tool interfaces, retrieval, safety controls, and other layers, but generation remains central.

This distinction matters because prose instructions do not become executable specifications merely because the model often follows them.

Consider a normal function:

```text
calculate_tax(income, jurisdiction, tax_year) -> amount
```

The engineer expects:

- a defined input contract,
- a known implementation,
- explicit dependencies,
- repeatable tests,
- inspectable failure modes,
- and a result traceable to encoded rules.

Now consider:

```text
"Calculate the tax for this taxpayer and explain your answer."
```

The request may imply dozens of missing decisions:

- Which laws are authoritative?
- Are the supplied facts complete?
- Should external sources be consulted?
- What date applies?
- What level of precision is required?
- May the model infer missing facts?
- How should uncertainty be represented?
- Who verifies the calculation?

The natural-language interface makes an underspecified task look deceptively complete.

### Engineering consequence

When a task is expressed in natural language, ambiguity does not disappear. It moves into the model's interpretation. Good AI engineering makes that ambiguity visible again through schemas, task contracts, examples, tools, constraints, and validation.

---

## 2. The Transformer Changed the Interface to Computation

The 2017 Transformer paper replaced recurrent sequence processing with an architecture centered on attention mechanisms. Attention allows a model to compute relationships among tokens in the supplied sequence and made training highly parallelizable. Later scaling work demonstrated that sufficiently large autoregressive models could perform new tasks from instructions and examples placed directly in context, without task-specific parameter updates.

This capability is commonly called **in-context learning**. The phrase can mislead beginners because the model usually does not permanently learn from the interaction. It adapts its immediate behavior based on the patterns and examples available in the current context.

That produces a powerful engineering property:

> Behavior can be programmed partly through data supplied at runtime.

Examples, policies, tool descriptions, retrieved documents, prior decisions, and output schemas can all alter the model's behavior without modifying its weights.

But the same property creates fragility:

- behavior depends on what was supplied,
- how it was represented,
- where it appeared,
- what conflicting material accompanied it,
- and whether the model successfully used it.

A traditional program separates code from runtime data relatively clearly. In an LLM interaction, instructions, examples, facts, intermediate work, and untrusted content may all inhabit the same token sequence. Engineering the boundaries among those categories is therefore essential.

---

## 3. Context Is Working Memory, Not a Knowledge Guarantee

A context window defines how much input a model can process in an interaction. It is tempting to treat a larger window as equivalent to perfect memory: if the information fits, the model knows it.

Research does not support that assumption.

The “Lost in the Middle” experiments showed that models can use information differently depending on its position. Performance was often strongest when relevant material appeared near the beginning or end and weaker when it appeared in the middle. Later work has proposed training and inference methods that improve long-context use, but the underlying lesson remains important: **capacity is not utilization**.

A document inside the window may still be:

- overlooked,
- weakly weighted,
- confused with another document,
- interpreted under the wrong instruction,
- or used incompletely during multi-step reasoning.

This means that context engineering is not equivalent to copying everything into a prompt.

### A better model: context compilation

Treat the active context as a compiled working set assembled for a specific task.

A context compiler conceptually performs these steps:

1. Identify the task and acceptance criteria.
2. Identify authoritative project state.
3. Retrieve only relevant evidence and code.
4. Resolve or expose conflicts.
5. Order material so instructions and evidence are legible.
6. Mark trust boundaries.
7. Fit the result into the available budget.
8. Preserve citations or provenance for verification.

This resembles compilation because raw project knowledge is transformed into a task-specific representation. The entire repository, all prior conversations, and every research note are source material; the active context is the executable working set.

### Why “AI is stateless” is incomplete

The phrase is operationally useful but technically imprecise.

A deployed AI system may include:

- conversation history,
- server-side memory,
- retrieved user data,
- cached computations,
- persistent tool state,
- model-provider personalization,
- or an agent runtime with durable checkpoints.

The model's weights also encode extensive learned statistical structure. It is therefore wrong to imply that nothing persists.

The important distinction is this:

> The model does not automatically possess the authoritative, current, task-specific state of your project.

That state must be managed by the surrounding system.

---

## 4. Fluency Is Not Evidence

Language models are optimized to generate coherent continuations. Coherence and truth frequently align, but they are not the same objective.

A model can produce:

- a syntactically valid function calling a nonexistent library,
- a polished summary that reverses a source's conclusion,
- a legal citation with plausible formatting but no real case,
- a confident diagnosis unsupported by the supplied evidence,
- or an architectural recommendation that silently violates a project constraint.

The term **hallucination** is widely used for unsupported or false generated content. It is useful colloquially, but it can hide several distinct failure modes:

1. **Parametric knowledge error:** the model's learned representation is wrong, incomplete, or outdated.
2. **Retrieval failure:** the system retrieves irrelevant or insufficient evidence.
3. **Grounding failure:** correct evidence is present but the answer is not supported by it.
4. **Instruction conflict:** competing instructions or documents redirect behavior.
5. **Reasoning failure:** the model makes an invalid inference.
6. **Tool failure:** an external action returns incomplete or misleading data.
7. **Interface failure:** the user interprets tentative language as an authoritative answer.
8. **Evaluation failure:** the workflow has no reliable mechanism to detect the problem.

The final category is especially important. A generative error becomes an engineering defect when the system permits it to pass as accepted output.

### Correctness moves outward

In ordinary software, correctness is often established through code review and tests applied to an implementation. In AI systems, correctness must also be established around generation:

- retrieved claims should link to sources,
- code should compile and pass tests,
- structured output should validate against a schema,
- calculations should use deterministic tools,
- decisions should expose assumptions,
- and high-impact actions should require approval.

The model is not exempt from validation because it speaks persuasively. Its persuasiveness is precisely why validation must be explicit.

---

## 5. The Model Is a Candidate Generator, Not Automatically the Authority

The most useful general mental model for engineering work is:

> The model proposes candidates; the system decides what becomes authoritative.

A candidate may be:

- a code patch,
- a plan,
- a query,
- a diagnosis,
- a classification,
- a summary,
- a tool call,
- or a research hypothesis.

The control system then evaluates the candidate using mechanisms appropriate to the domain.

```text
Task
  |
  v
Context assembly
  |
  v
LLM generates candidate
  |
  v
Deterministic checks / retrieval / tests / review
  |
  +---- reject, revise, or escalate
  |
  v
Accepted artifact or action
```

This architecture avoids two extremes.

The first extreme is **automation theater**, where the model produces text but humans must redo all meaningful work. The second is **unbounded delegation**, where persuasive output is accepted without sufficient control.

The goal is calibrated delegation: automate where verification is reliable and the cost of error is acceptable; constrain or review where it is not.

---

## 6. Prompt Engineering Is Necessary but Not Sufficient

Prompt engineering improves the instructions and examples supplied to a model. It remains important. Clear objectives, relevant context, explicit constraints, and good examples can materially improve outcomes.

But prompt-centric thinking breaks down as tasks grow.

A complex engineering task may require:

- discovering relevant files,
- inspecting current APIs,
- executing tests,
- comparing alternatives,
- preserving intermediate decisions,
- recovering after failure,
- coordinating parallel work,
- and updating durable documentation.

No single prompt solves those concerns. They belong to a workflow.

### The stack of AI engineering

A useful decomposition is:

1. **Model layer**  
   The model's capabilities, limitations, latency, cost, and context capacity.

2. **Instruction layer**  
   System policies, task instructions, examples, output formats, and constraints.

3. **Context layer**  
   Retrieval, selection, ordering, provenance, compression, and trust boundaries.

4. **Tool layer**  
   Search, code execution, databases, browsers, compilers, test runners, and APIs.

5. **State layer**  
   Checkpoints, artifacts, memory, task status, decisions, and logs.

6. **Evaluation layer**  
   Tests, graders, schemas, simulations, source checks, and human review.

7. **Orchestration layer**  
   Task decomposition, routing, retries, budgets, escalation, and stopping rules.

8. **Governance layer**  
   Authority, privacy, security, auditability, risk tolerance, and accountability.

Prompt quality affects one layer. Reliable AI engineering depends on the interaction of all eight.

---

## 7. Why the Same AI Can Help One Engineer and Slow Another

Claims that AI “makes developers faster” or “makes developers slower” are both too broad.

Studies have reported productivity improvements in some organizational and experimental settings, often with larger gains among less-experienced workers. Other research, including a randomized study of experienced open-source developers working in familiar repositories, found that early-2025 AI tools increased completion time by 19 percent in that setting. A 2026 follow-up described newer data with uncertain but more favorable estimates, illustrating how quickly tool capability and user practice can change.

These findings are not necessarily contradictory. They may describe different tasks and systems.

AI value depends on at least six variables:

### 1. Task decomposability

Can the work be broken into units with clear boundaries and acceptance criteria? Generating a small adapter with existing tests is different from understanding a poorly documented cross-cutting production defect.

### 2. Verification cost

Can output be checked cheaply? A generated parser with a strong test suite is easier to trust than a strategic architectural recommendation whose consequences may take months to appear.

### 3. Context accessibility

Can the system obtain the relevant information? A model working against a documented, searchable repository has a different task from one trying to infer unwritten organizational knowledge.

### 4. User expertise

Experts may detect subtle errors but can also spend more time correcting them. Novices may receive larger immediate gains while being less able to recognize defects. Neither group automatically benefits.

### 5. Interaction friction

Slow tools, repeated approvals, poor diffs, limited repository access, and context reconstruction can erase generation speed.

### 6. Learning and calibration

Users need experience choosing tasks, scoping requests, checking output, and knowing when to stop using the model. Productivity is partly a property of the human-AI system, not the model alone.

### Decision rule

Do not ask, “Is AI productive?”

Ask:

> For this user, task, repository, model, interface, and verification process, does AI reduce total time to an accepted result without increasing unacceptable risk?

That is measurable.

---

## 8. Durable Artifacts Are the Bridge Across Interactions

Conversations are useful for exploration, but they are poor as the sole system of record.

A long-running project needs durable artifacts such as:

- architecture decision records,
- accepted requirements,
- repository maps,
- research evidence,
- experiment results,
- test reports,
- task contracts,
- known limitations,
- and unresolved questions.

Why do artifacts matter?

First, they make knowledge inspectable. A future agent or engineer can distinguish an accepted decision from speculative discussion.

Second, they make retrieval possible. A system can search a structured decision log more reliably than replaying months of chat.

Third, they create review boundaries. A document or patch can be approved, versioned, compared, and reverted.

Fourth, they reduce repeated reasoning. An expensive investigation becomes reusable context.

### Artifact-first does not mean document everything

Excess documentation creates its own retrieval problem. Preserve information when it has future decision value:

- a decision that constrains later work,
- evidence expensive to rediscover,
- an assumption whose failure would matter,
- a procedure required for safe operation,
- or an interface others depend on.

Do not preserve every conversational branch merely because it occurred.

---

## 9. A Practical Control Architecture

A reliable AI-assisted workflow can be designed around five control questions.

### Question 1: What may the model decide?

Define its authority.

Examples:

- It may draft a migration plan but not execute it.
- It may edit files on a branch but not merge.
- It may query production metrics but not change infrastructure.
- It may recommend a medical question to ask, but not replace a clinician.

### Question 2: What must it know?

Define the minimum sufficient context:

- current objective,
- applicable constraints,
- relevant files,
- authoritative sources,
- accepted decisions,
- and output criteria.

### Question 3: What tools should it use?

Prefer deterministic tools for deterministic work:

- calculators for arithmetic,
- compilers for syntax and type checking,
- tests for behavioral constraints,
- databases for current records,
- and source retrieval for factual claims.

The model should orchestrate or interpret these tools rather than imitate them unreliably.

### Question 4: How will the result be verified?

Verification should match the output:

| Output | Verification |
|---|---|
| Code patch | build, tests, static analysis, review |
| Factual report | citations, source comparison, date checks |
| Data transformation | schema validation, invariants, sampling |
| Plan | constraint review, risk analysis, stakeholder approval |
| Tool action | permissions, dry run, audit log, rollback |
| Summary | comparison with source, coverage checks |

### Question 5: What persists?

Record:

- accepted outputs,
- decisions,
- evidence,
- failures worth avoiding,
- unresolved risks,
- and the next known state.

The answer should not be “the chat.”

---

## 10. Common Misconceptions

### Misconception 1: The model understands the project because it discussed it before

A conversation may provide continuity, but continuity is conditional on what remains available and salient. Preserve authoritative state externally.

### Misconception 2: A larger context window eliminates retrieval

A larger window reduces some constraints, but retrieval still controls relevance, provenance, cost, and attention competition.

### Misconception 3: Low temperature makes output correct

Decoding settings can affect variability. They do not turn unsupported knowledge into verified fact.

### Misconception 4: More agents mean more intelligence

Multiple agents add coordination cost and can amplify shared errors. Specialization helps only when task boundaries, independent evidence, or parallelism justify it.

### Misconception 5: The model's explanation reveals its true internal reasoning

Generated explanations can be useful artifacts, but they should not automatically be treated as faithful traces of internal computation.

### Misconception 6: AI-generated code is cheaper because typing is faster

Total cost includes specification, context assembly, review, testing, rework, maintenance, and learning effects.

### Misconception 7: The model should always answer

A well-engineered system must support abstention, escalation, additional retrieval, and requests for missing evidence.

---

## 11. A Decision Framework for Using AI

Before assigning a task, score it qualitatively across four dimensions.

### A. Generative advantage

Does the task benefit from rapid synthesis, transformation, exploration, or candidate generation?

### B. Context readiness

Is the relevant information available, current, and retrievable?

### C. Verifiability

Can correctness be checked at acceptable cost?

### D. Consequence of error

What happens if a plausible but wrong result is accepted?

This produces four broad patterns:

#### High advantage, high verifiability

Excellent candidates:
- test generation,
- bounded refactoring,
- format conversion,
- draft documentation from accepted code,
- query generation with execution checks.

#### High advantage, low verifiability

Use for exploration, not authority:
- strategy,
- novel architecture,
- ambiguous diagnosis,
- forecasting,
- research synthesis without source review.

#### Low advantage, high verifiability

Automation may still help, but deterministic software may be better:
- arithmetic,
- simple validation,
- exact lookup,
- stable transformations.

#### Low advantage, low verifiability

Avoid or redesign the task.

---

## 12. The Foundational Mental Model

The most durable summary of this chapter is:

> An LLM is a probabilistic reasoning and generation component embedded in a deterministic control system.

“Probabilistic” reminds us that output is generated rather than guaranteed.

“Reasoning and generation component” acknowledges genuine capability without pretending the model is merely autocomplete.

“Embedded” emphasizes that useful behavior depends on context, tools, state, evaluation, and governance.

“Deterministic control system” does not mean every surrounding component is perfectly deterministic. It means authority, permissions, validation, transitions, and acceptance criteria should be explicitly engineered rather than delegated to persuasive prose.

This mental model leads naturally to the remainder of AI engineering:

- Context engineering asks what the model should see.
- Retrieval asks how relevant evidence is found.
- Tool engineering asks what external capabilities it should use.
- Memory engineering asks what state should persist.
- Agent engineering asks how work should be decomposed and controlled.
- Evaluation asks how candidates become accepted results.
- Governance asks who remains accountable.

---

## Summary

AI engineering differs from ordinary software integration because language models combine a general natural-language interface with probabilistic generation, runtime adaptation from context, broad but uneven capability, and fluent failure.

The correct response is neither blind trust nor rejection. It is architecture.

Reliable systems:

- make task ambiguity explicit,
- compile task-specific context,
- retrieve authoritative information,
- use deterministic tools where appropriate,
- treat model output as a candidate,
- verify before acceptance,
- preserve durable state in artifacts,
- and calibrate delegation to task risk.

The first skill in AI engineering is therefore not writing clever prompts. It is learning to place a generative model inside a system that knows what the model may do, what it must know, how its work will be checked, and what survives after the interaction ends.

---

## Key Takeaways

1. Natural language is a flexible interface, not an executable specification.
2. Context capacity does not guarantee reliable context use.
3. Fluency is not evidence of correctness.
4. Prompt engineering is one layer of a larger AI engineering stack.
5. Model output should usually be treated as a candidate awaiting validation.
6. AI productivity depends on task-system fit, not adoption alone.
7. Durable artifacts provide authoritative project memory.
8. Verification and governance are functional requirements, not administrative extras.
9. Use deterministic tools for deterministic subproblems.
10. Engineer the full human-model-tool system.
