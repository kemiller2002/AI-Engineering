# Suggested Diagrams
## Chapter 1 — Why AI Engineering Is Different

## Figure 1: Conventional execution versus generative execution

A side-by-side flow.

Left:
`Typed input -> Explicit program -> Determinate/defined output contract`

Right:
`Natural-language task + context -> Generative model -> Candidate -> Verification -> Accepted output`

Purpose: Show that verification is part of the AI path rather than an optional final step.

## Figure 2: The AI engineering stack

Eight horizontal layers:

1. Governance
2. Orchestration
3. Evaluation
4. State
5. Tools
6. Context
7. Instructions
8. Model

Arrows should show that failures can originate at any layer and that output quality cannot be attributed to the model alone.

## Figure 3: Context compilation pipeline

`Project repository + decisions + current task + retrieved evidence + policies`
into a “context compiler,” producing:
`task-specific working context`

A rejected-material branch should show irrelevant, stale, conflicting, or untrusted material being excluded or flagged.

## Figure 4: Candidate acceptance loop

`Generate -> Check -> Accept`
with alternative paths:
`Check -> Retrieve more -> Regenerate`
`Check -> Human escalation`
`Check -> Reject`

Purpose: Explain controlled iteration without implying that retries guarantee truth.

## Figure 5: Task-system fit matrix

Two axes:

- X-axis: verification cost, low to high
- Y-axis: generative advantage, low to high

Four quadrants:
- automate with checks,
- use for exploration,
- prefer deterministic software,
- redesign or avoid.

## Figure 6: Durable state boundary

Inside temporary interaction:
- prompt,
- retrieved context,
- intermediate reasoning,
- tool results.

Outside in durable project state:
- accepted decisions,
- artifacts,
- tests,
- evidence,
- checkpoints.

A gate labeled “review and persist” separates them.
