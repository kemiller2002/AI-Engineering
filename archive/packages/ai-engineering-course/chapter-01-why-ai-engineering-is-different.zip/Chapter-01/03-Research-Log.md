# Research Log
## Chapter 1 — Why AI Engineering Is Different

## Scope decision

The chapter began with the proposed claim that “AI is stateless; your project should not be.” Research and critique showed that this is a useful workflow slogan but an inadequate technical foundation. Modern systems may possess conversation history, retrieval, persistent agent state, tool state, caches, and provider-side memory.

The chapter was therefore reframed around a stronger claim:

> An LLM is a probabilistic reasoning and generation component embedded in a deterministic control system.

## Questions investigated

1. What technically distinguishes LLM interaction from conventional programming?
2. What role did the Transformer and in-context learning play?
3. Does information being inside a context window guarantee its use?
4. Why can fluent output be wrong?
5. Is prompt engineering the primary determinant of effective use?
6. Does AI reliably improve developer productivity?
7. What should persist across interactions?
8. Which aspects of AI behavior should be controlled by deterministic mechanisms?
9. When should AI not be used?
10. Which claims are established and which remain emerging practice?

## Verified or strongly supported findings

- Transformers use attention-based architectures to model relationships among sequence elements.
- Large autoregressive models can adapt behavior from instructions and examples supplied in context.
- Long-context capacity does not imply uniform or reliable use of all included information.
- Retrieval can combine model generation with external non-parametric information.
- Generative AI creates distinctive risks requiring governance, measurement, and management.
- Developer productivity effects vary by setting and should not be generalized from a single study.

## Assumptions rejected or revised

### Rejected: “AI is simply stateless”

Revised to distinguish model weights, ephemeral context, persistent application state, retrieval, and external memory.

### Rejected: “Traditional software is deterministic; AI is nondeterministic”

Too simplistic. Traditional systems can be stochastic, concurrent, distributed, and adaptive. The important difference is the combination of probabilistic generation, natural-language control, broad task generality, and fluent unsupported output.

### Rejected: “Prompt quality is the dominant differentiator”

Prompt quality matters, but complex outcomes depend on context, tools, state, evaluation, orchestration, user expertise, and verification.

### Rejected: “AI improves developer productivity”

Evidence is heterogeneous. The defensible conclusion is conditional: productivity depends on task, user, tool, repository, and verification process.

### Revised: “Large context means memory”

Context capacity is better understood as available working input. Utilization is imperfect and task-dependent.

## Competing viewpoints

### Viewpoint: models are only stochastic parrots

This critique usefully emphasizes statistical generation and the danger of anthropomorphism. It is insufficient as an engineering model because it understates tool use, structured inference, in-context adaptation, and practical task capability.

### Viewpoint: models are reasoning agents comparable to human workers

This captures their ability to perform multi-step tasks and use tools, but it risks assigning stable intention, memory, and accountability that belong to the surrounding system.

### Viewpoint: LLMs are advanced autocomplete

This accurately points to next-token prediction but is too reductive for system design. The emergent behavior of scaled models, instruction tuning, tools, and inference-time computation matters operationally.

### Viewpoint: prompt engineering is becoming obsolete

Overstated. Prompt construction remains necessary, but it is being subsumed into broader context and workflow engineering.

## Remaining uncertainties

- There is no universally accepted definition of “AI engineering.”
- The boundary between model reasoning and sophisticated pattern completion remains scientifically and philosophically debated.
- Long-context performance is improving, so specific failure profiles may age quickly.
- Productivity evidence is highly sensitive to tool generation, study design, task selection, and user adaptation.
- The best balance among single-agent, multi-agent, and deterministic workflows is task-dependent and not settled.

## Design decisions

1. Teach the model as a candidate generator inside a controlled system.
2. Avoid anthropomorphic role analogies as the primary explanation.
3. Introduce context compilation before detailed prompt techniques.
4. Treat verification as part of architecture.
5. Present productivity as an empirical question for a defined task system.
6. Preserve uncertainty explicitly.
