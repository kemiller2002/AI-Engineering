# Executive Summary
## Chapter 1 — Why AI Engineering Is Different

Traditional software is designed around explicit instructions, defined interfaces, inspectable state, and repeatable execution. Large language models introduce a different kind of component: a probabilistic generator that interprets natural-language context, adapts behavior from examples supplied at inference time, and can produce useful but unsupported output with the same fluency as correct output.

The central conclusion of this chapter is not that AI is mysterious or inherently unreliable. It is that AI requires a different control architecture.

A conventional function is usually treated as the authority for the behavior encoded in it. An LLM should usually be treated as a candidate generator operating inside a larger engineered system. That system supplies context, constrains available actions, retrieves authoritative information, verifies outputs, preserves durable state, and determines when human judgment is required.

This produces five foundational shifts:

1. **From instruction execution to probabilistic generation.**  
   A model generates a plausible continuation conditioned on its inputs; it does not execute prose as a conventional program executes source code.

2. **From stored application state to compiled working context.**  
   Relevant state must be selected, transformed, and supplied. A large context window increases capacity, but does not guarantee that every included fact will be used reliably.

3. **From correctness by construction to correctness by validation.**  
   Fluent output is not proof. Tests, source verification, schemas, static checks, simulations, and human review become part of the functional design.

4. **From monolithic prompting to workflow engineering.**  
   Prompt wording matters, but complex work depends increasingly on decomposition, retrieval, tools, artifacts, feedback loops, and stopping conditions.

5. **From AI adoption to task-system fit.**  
   AI does not improve every task. Research on developer productivity shows gains in some settings and slowdowns in others. Effective use depends on task characteristics, user expertise, tooling friction, verification cost, and the quality of the surrounding workflow.

The practical mental model is:

> An LLM is a probabilistic reasoning and generation component embedded in a deterministic control system.

This is deliberately more precise than calling the model a “junior engineer,” “autocomplete,” “search engine,” or “oracle.” Each analogy captures something useful, but each hides important failure modes.

The chapter recommends beginning AI work by asking:

- What authority does the model have?
- What information must be supplied?
- Which sources are authoritative?
- How will output be checked?
- What state must survive the interaction?
- What happens when the model is uncertain or wrong?
- Is the task valuable enough to justify the coordination and verification cost?

These questions form the foundation for the rest of the course: context engineering, retrieval, tool use, agent design, evaluation, memory, governance, and token economics.
