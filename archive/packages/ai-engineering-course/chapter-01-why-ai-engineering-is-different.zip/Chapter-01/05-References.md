# References
## Chapter 1 — Why AI Engineering Is Different

## Foundational academic papers

1. Vaswani, A. et al. **Attention Is All You Need** (2017).  
   https://arxiv.org/abs/1706.03762

2. Brown, T. et al. **Language Models are Few-Shot Learners** (2020).  
   https://arxiv.org/abs/2005.14165

3. Lewis, P. et al. **Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks** (2020).  
   https://arxiv.org/abs/2005.11401

4. Liu, N. F. et al. **Lost in the Middle: How Language Models Use Long Contexts** (2023).  
   https://arxiv.org/abs/2307.03172

## Long-context follow-up research

5. He, J. et al. **Never Lost in the Middle: Mastering Long-Context Question Answering with Position-Agnostic Decompositional Training** (2023/2024).  
   https://arxiv.org/abs/2311.09198

6. Baker, G. A. et al. **Lost in the Middle, and In-Between: Enhancing Language Models' Ability to Reason Over Long Contexts in Multi-Hop QA** (2024).  
   https://arxiv.org/abs/2412.10079

## Engineering productivity

7. Becker, J., Rush, N., Barnes, B., and Rein, D. **Measuring the Impact of Early-2025 AI on Experienced Open-Source Developer Productivity** (2025).  
   https://metr.org/blog/2025-07-10-early-2025-ai-experienced-os-dev-study/

8. METR. **We are Changing our Developer Productivity Experiment** (2026 update).  
   https://metr.org/blog/2026-02-24-uplift-update/

## Standards and governance

9. NIST. **Artificial Intelligence Risk Management Framework (AI RMF 1.0)** (2023).  
   https://nvlpubs.nist.gov/nistpubs/ai/nist.ai.100-1.pdf

10. NIST. **Artificial Intelligence Risk Management Framework: Generative Artificial Intelligence Profile (NIST AI 600-1)** (2024).  
    https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.600-1.pdf

## Notes on evidence quality

- Foundational papers establish architectural and behavioral capabilities but do not by themselves prove a preferred software-engineering workflow.
- Productivity studies are context-sensitive and should not be generalized beyond their populations and tasks.
- “Context engineering” and “artifact-first workflow” are emerging engineering formulations, not mature standards.
