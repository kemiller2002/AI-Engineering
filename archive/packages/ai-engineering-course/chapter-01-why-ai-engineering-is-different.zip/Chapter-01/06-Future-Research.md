# Future Research and Chapter Dependencies

## Topics requiring dedicated chapters

1. **How language models work at an engineering level**  
   Tokens, embeddings, attention, training, instruction tuning, inference, decoding, and tool use.

2. **Context engineering**  
   Retrieval, selection, ordering, compression, provenance, trust boundaries, and context evaluation.

3. **Verification and evaluation**  
   Deterministic tests, model graders, source checking, uncertainty, benchmark design, and production monitoring.

4. **Memory and durable state**  
   Conversation memory, episodic memory, semantic memory, artifact stores, checkpoints, and invalidation.

5. **Agent architecture**  
   Planning, tool use, state machines, retries, stopping conditions, multi-agent coordination, and recovery.

6. **AI-assisted software engineering productivity**  
   Measurement design, task selection, quality effects, skill development, review burden, and organizational adoption.

7. **Human factors**  
   Automation bias, cognitive offloading, deskilling, calibration, trust, attention, and learning.

8. **Security**  
   Prompt injection, data exfiltration, tool permissions, sandboxing, supply-chain risks, and auditability.

9. **Economics**  
   Token cost, latency, verification cost, rework, opportunity cost, and value per accepted artifact.

10. **Governance**  
    Accountability, authority boundaries, risk classification, privacy, compliance, and incident response.

## Questions carried forward

- How should context quality be measured?
- When is generated reasoning useful as evidence?
- Which tasks should use model-based versus deterministic evaluators?
- How should teams quantify the cost of verification?
- When does persistent memory improve performance versus propagate stale assumptions?
- What learning practices prevent AI assistance from weakening engineering skill?
